
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Models from "./pages/Models";

export default function App() {
  return (
    <Router>
      <nav className="bg-gray-100 p-4 flex gap-4 shadow sticky top-0 z-50">
        <Link to="/" className="text-blue-700 font-semibold hover:underline">Home</Link>
        <Link to="/about" className="text-blue-700 font-semibold hover:underline">Ultrasonic 101</Link>
        <Link to="/models" className="text-blue-700 font-semibold hover:underline">Models We Service</Link>
        <Link to="/contact" className="text-blue-700 font-semibold hover:underline">Contact</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/models" element={<Models />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}
